MedQ Daily complete repair package. See README-DEPLOY.txt for deployment instructions.
